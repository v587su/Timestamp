"""
Spew - A generator for Python. It uses Python to generate valid Python code.
"""

__version__ = "1.0.2"
